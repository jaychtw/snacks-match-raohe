/** Minimal presentation model: consumes the public event stream, never matches pieces. */
export class EventConsumer {
  constructor(state) {
    this.board = structuredClone(state.board);
    this.score = state.score;
    this.moves = state.moves;
    this.status = state.status;
    this.cleared = structuredClone(state.cleared);
    this.seen = [];
  }
  consume(events) {
    for (const event of events) {
      this.seen.push(event.type);
      switch (event.type) {
        case 'swapped': {
          const { from, to } = event.move;
          [this.board[from.row][from.col], this.board[to.row][to.col]] = [this.board[to.row][to.col], this.board[from.row][from.col]];
          this.moves = event.moves;
          break;
        }
        case 'specialCreated':
        case 'specialConverted': this.board[event.at.row][event.at.col] = structuredClone(event.piece); break;
        case 'eliminated':
          for (const { row, col, piece } of event.cells) {
            this.board[row][col] = null;
            if (piece.type !== null) this.cleared[piece.type]++;
          }
          break;
        case 'fell':
          // Moves are simultaneous: clear all origins before setting any destination.
          for (const { from } of event.pieces) this.board[from.row][from.col] = null;
          for (const { piece, to } of event.pieces) this.board[to.row][to.col] = structuredClone(piece);
          break;
        case 'refilled': for (const cell of event.cells) this.board[cell.row][cell.col] = structuredClone(cell.piece); break;
        case 'scored': this.score = event.total; break;
        case 'completed': this.status = event.status; break;
        case 'reshuffled': this.board = structuredClone(event.board); break;
      }
    }
  }
  verify(state) {
    for (const field of ['board', 'score', 'moves', 'status', 'cleared']) {
      if (JSON.stringify(this[field]) !== JSON.stringify(state[field])) throw new Error(`Event projection mismatch: ${field}`);
    }
  }
}
