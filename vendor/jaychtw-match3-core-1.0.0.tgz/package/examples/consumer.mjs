import { createGame, loadGame } from '../dist/index.js';
import { EventConsumer } from './event-consumer.mjs';

const game = createGame({ objectives: [{ kind: 'score', target: 500 }], moveLimit: 20 }, 'shape-match-integration');
const consumer = new EventConsumer(game.state);
const moves = game.listLegalMoves();
if (!moves.length) throw new Error('No playable entry point');
const result = game.applyMove(moves[0]);
if (!result.ok) throw new Error(result.error.message);
consumer.consume(result.events);
consumer.verify(result.state);
const saved = game.serialize();
const restored = loadGame(saved);
if (restored.serialize() !== saved) throw new Error('Save/restore mismatch');
const next = game.listLegalMoves()[0];
if (next) {
  const originalResult = game.applyMove(next), restoredResult = restored.applyMove(next);
  if (JSON.stringify(originalResult) !== JSON.stringify(restoredResult)) throw new Error('Replay diverged');
  if (!originalResult.ok) throw new Error(originalResult.error.message);
  consumer.consume(originalResult.events);
  consumer.verify(originalResult.state);
}
console.log(JSON.stringify({ seed: 'shape-match-integration', availableMoves: moves.length, score: game.state.score, moves: game.state.moves, events: consumer.seen, eventProjection: 'passed', saveRestoreReplay: 'passed' }, null, 2));
