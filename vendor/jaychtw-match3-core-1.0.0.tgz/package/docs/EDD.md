# Match3 Core — Engine Design Document

**Version:** 0.1.0  
**Status:** Design baseline — ready for technical implementation planning  
**Repository:** `jaychtw/match3-core` (proposed)  
**Engine type:** Headless, reusable TypeScript library  
**First consumer:** Shape Match  
**Other planned consumers:** Cute Animal Match; Taiwan Snack Match  
**Governing standard:** UGDS v1.0.0, pinned to commit `d5c6696efdd6efc028118600466db44aecae0c9b`

## 1. Purpose

Match3 Core provides a deterministic, configurable, presentation-independent engine for match-3 puzzle games.

It owns the rules and state transitions necessary to play match-3 games but does not own their visual identities, user interfaces, narratives, sound, animation, or game-specific progression.

**Design principle:** One engine, multiple games, distinct experiences.

The first implementation must support a complete conventional match-3 ruleset without prematurely building an elaborate plugin framework.

## 2. Architecture and boundaries

### 2.1 Core responsibilities

The engine MUST support:

- Board initialization and validation.
- Configurable board dimensions and piece types.
- Adjacent-piece swaps and validity checks.
- Detection of horizontal, vertical, and intersecting matches.
- Special-piece creation and activation.
- Gravity, replenishment, and cascades.
- Deterministic randomness.
- Scoring and objective evaluation.
- Legal-move detection and reshuffling.
- Serializable game state.
- Structured events for presentation and animation.
- Automated simulation and testing.

### 2.2 Outside the engine

Individual games own:

- Artwork, animation, sound, and visual effects.
- Mouse, keyboard, and touch input.
- UI layout and accessibility presentation.
- English and Traditional Chinese localization.
- Themes, character identities, and story.
- Level design and game-specific objectives.
- Player progress and persistence infrastructure.
- Deployment and platform integration.

The engine may expose abstract identifiers and objective primitives but must not reference shapes, animals, Taiwanese snacks, or other presentation-specific concepts.

### 2.3 Dependencies

The engine must have no browser DOM or rendering dependency and must run in Node.js and modern browser JavaScript environments.

Prefer minimal runtime dependencies and locally bundled functionality.

## 3. Default gameplay rules

### 3.1 Board

The reference configuration uses:

- 8×8 rectangular board.
- Six distinct piece types.
- One piece per playable cell.
- Orthogonal adjacency for swaps.
- Downward gravity.
- No diagonal matching.

Board dimensions and piece-type count are configurable, subject to validation.

### 3.2 Swapping

A player may attempt to swap two orthogonally adjacent cells.

A swap is valid only if it creates an immediate match involving at least one swapped cell or triggers an explicitly supported special-piece interaction.

Invalid swaps:

- Leave the logical board unchanged.
- Do not consume a move.
- Produce a structured rejection event.
- May be animated as a swap-and-return by the consuming game.

The core does not implement animation timing.

### 3.3 Standard matches

| Pattern | Default outcome |
|---|---|
| Three in a straight line | Remove matched pieces |
| Four horizontal | Create horizontal line-clearer |
| Four vertical | Create vertical line-clearer |
| Five or more in a straight line | Create same-type clearer |
| L- or T-shaped intersection, five or more cells | Create area bomb |

For longer straight matches, the five-or-more rule takes precedence over the four-piece rule.

A match's special piece is created at a deterministic anchor, preferring an eligible swapped cell when applicable.

The engine must document and test its tie-breaking rules for ambiguous or overlapping matches.

### 3.4 Special pieces

**Horizontal line-clearer:** Clears the entire playable row when activated.

**Vertical line-clearer:** Clears the entire playable column when activated.

**Same-type clearer:** Clears all ordinary pieces of the selected type across the board.

**Area bomb:** Clears a configurable neighborhood, defaulting to a 3×3 region centered on the activated piece.

Special pieces retain an underlying piece type where appropriate. Same-type clearers may use a distinct type-neutral representation.

### 3.5 Special activation

Special pieces may be activated by:

- Being included in a match.
- A valid swap involving a special piece, when permitted by the relevant rule.
- A chain reaction caused by another special effect.

A newly created special piece must not immediately activate solely because it was created.

The engine must prevent duplicate activation, repeated scoring, and infinite effect chains.

Special-piece combinations require explicit deterministic rules and test coverage. The initial release must support conventional interactions without introducing an unrestricted effect-scripting system.

## 4. Turn resolution

Each valid move follows a deterministic sequence:

1. Validate the attempted action.
2. Apply the swap.
3. Detect resulting matches or special interactions.
4. Classify match patterns and resolve overlapping groups.
5. Create applicable special pieces.
6. Resolve eliminations and triggered effects.
7. Apply gravity.
8. Replenish empty cells.
9. Detect and resolve cascades.
10. Evaluate objectives and scoring.
11. Check whether the game has ended.
12. Check legal moves and reshuffle if necessary.
13. Return the resulting state and ordered event log.

The precise internal order of special-piece placement, elimination, and cascade processing must be specified and verified so results do not depend on iteration order.

The entire move resolves logically without waiting for visual animations.

## 5. Determinism

The engine MUST support seedable pseudorandom generation.

Given the same:

- Initial configuration.
- Initial board state.
- Random seed or generator state.
- Sequence of player actions.

…the engine must produce identical final states and event sequences.

Random-generator state must be included in serialized state or otherwise preserved for exact replay.

Avoid dependence on `Math.random()`, wall-clock time, animation frames, or browser rendering behavior.

## 6. Board initialization and reshuffling

### 6.1 Initial board

The default generator must produce a board with:

- No pre-existing automatic matches.
- At least one legal move.
- Valid piece identifiers and dimensions.

It must not rely on an unbounded retry loop.

### 6.2 Deadlocked board

When no legal move remains, the engine must initiate a deterministic reshuffle.

Reshuffling must:

- Preserve required immutable board elements.
- Preserve applicable special-piece attributes unless an explicit rule permits otherwise.
- Avoid creating immediate matches.
- Restore at least one legal move.
- Return an event explaining the reshuffle.

If a valid reshuffle is mathematically impossible under the configuration, the engine must return a typed, recoverable error rather than hang or silently modify rules.

## 7. Objectives and scoring

The engine must provide configurable objective primitives sufficient for initial match-3 games, including:

- Reach a target score.
- Clear a specified quantity of pieces of one or more types.
- Complete an objective within a move limit.

Objectives must be evaluated from authoritative game events and state transitions.

A move is consumed once per valid player action, regardless of how many cascades occur.

Scoring must be configurable, with a documented default for ordinary eliminations, special effects, and cascades.

The engine must not hard-code a game's story or presentation into objective definitions.

## 8. Public API

The implementation must provide a stable, typed interface for:

- Creating a new game.
- Loading and validating saved state.
- Inspecting the current board.
- Listing or checking legal moves.
- Applying a player action.
- Obtaining the resulting state.
- Reading ordered gameplay events.
- Checking objectives and terminal status.
- Exporting state for persistence or replay.

An illustrative interface:

```ts
const game = createGame(config, seed);

const result = game.applyMove({
  from: { row: 3, col: 2 },
  to: { row: 3, col: 3 }
});

console.log(result.state);
console.log(result.events);
```

The exact API shape is delegated to Codex, subject to type safety, clarity, deterministic behavior, and compatibility with browser-based consumers.

Events must contain enough information for a consuming game to animate swaps, eliminations, special activations, falling pieces, replenishment, scoring, reshuffles, and game completion without reconstructing hidden engine decisions.

## 9. State integrity and error handling

The engine must reject malformed configurations and corrupted serialized states safely.

Required invariants include:

- Valid board dimensions.
- Valid piece identifiers.
- No duplicate cell occupancy.
- Consistent special-piece metadata.
- Valid objective and move-limit values.
- Valid random-generator state.
- No unresolved intermediate state exposed as a completed turn.

Failed operations must not partially mutate authoritative state.

The core should prefer immutable state transitions or another implementation with equivalent transactional guarantees.

## 10. Configuration and extensibility

The initial engine must support configuration of:

- Board dimensions.
- Piece-type identifiers.
- Match and special-piece rules.
- Scoring values.
- Objective definitions.
- Move limits.
- Random seed.
- Relevant special-effect parameters.

Extensions must not undermine deterministic simulation.

Future games may require obstacles, blockers, portals, alternate gravity, or new special effects. These are not mandatory for the first release and must not be implemented speculatively.

## 11. Testing and verification

### 11.1 Unit tests

Cover:

- All legal and illegal swap cases.
- Horizontal, vertical, L-shaped, and T-shaped matches.
- Four-piece and five-piece special creation.
- Ambiguous and overlapping matches.
- Special activation and chain reactions.
- Gravity and replenishment.
- Multiple cascades.
- Deadlock detection and reshuffling.
- Objective completion and move limits.
- State serialization and validation.
- Invalid configurations and impossible states.

### 11.2 Property-based and simulation tests

Verify invariants across many generated boards and action sequences.

Required properties include:

- Deterministic replay.
- No missing or duplicated pieces in stable boards.
- No invalid identifiers.
- No infinite resolution loops.
- No unintended changes after rejected moves.
- Correct move consumption.
- Consistent scoring and objective accounting.

A simulation safety limit must produce an explicit failure rather than masquerade as successful resolution.

### 11.3 Integration test

Build a minimal consumer harness that:

1. Creates a board.
2. Reads the available moves.
3. Executes a move.
4. Consumes the event log.
5. Verifies the resulting state.
6. Saves and restores a session.

The harness may be headless or command-line based. A polished browser game is not required for engine acceptance.

## 12. Repository and release strategy

**Repository:** `jaychtw/match3-core`

The repository should contain:

- Engine source.
- Automated tests.
- Public API documentation.
- Configuration and state schemas.
- Deterministic examples.
- EDD and change history.
- GitHub Actions CI workflow.
- Versioned release notes.

GitHub Pages is not required.

Use semantic versioning. Changes that break consumers' public API or serialized-state compatibility must be documented and versioned appropriately.

Publishing to npm is optional; initial consumers may use a pinned Git dependency or another reproducible local package mechanism.

## 13. UGDS applicability

UGDS v1.0.0 is adopted as the governing development standard, with its immutable reference preserved.

Because Match3 Core is a headless library, game-presentation requirements such as in-engine visual POC, browser UI, touch controls, and visual-art acceptance do not apply directly to the library artifact.

Applicable engineering, state integrity, determinism, quality assurance, dependency, versioning, and reporting principles remain mandatory.

The consuming games must satisfy the full applicable UGDS requirements.

Any ambiguity about mandatory UGDS applicability must be documented and resolved before implementation; non-applicability is not permission for an undocumented waiver.

## 14. Exclusions from v1.0

The initial engine does not include:

- Rendering or animation systems.
- Audio.
- UI components.
- Localization resources.
- Online multiplayer.
- User accounts or cloud storage.
- Advertising or monetization.
- Procedurally generated levels.
- AI opponents.
- General-purpose visual level editors.
- Arbitrary effect scripting.
- Unrequested obstacle or physics systems.

## 15. Definition of done

Match3 Core v1.0 is technically ready for integration when:

1. All required engine mechanics are implemented.
2. Public API and state formats are documented.
3. Unit and simulation tests pass.
4. Deterministic replay is verified.
5. Invalid configurations and failure paths are tested.
6. GitHub Actions CI passes.
7. A minimal consumer harness demonstrates real integration.
8. A versioned release is available.
9. Known limitations are documented.
10. The implementation is ready to be consumed by Shape Match without duplicating matching logic.

**Final product-level acceptance occurs after integration into Shape Match.**

The core's technical acceptance does not establish that Shape Match is visually complete, enjoyable, accessible, or production-ready.