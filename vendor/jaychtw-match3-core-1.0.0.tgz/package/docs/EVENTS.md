# Event contract v1

`applyMove` and `reshuffle` return ordered events and an authoritative detached final state. Events and coordinates use post-swap positions unless explicitly named `from`/`to`. Wave numbers start at zero and reset each turn. The full discriminated TypeScript union is `GameEvent` in `src/types.ts`, shipped as declarations in `dist/`.

Events are JSON-compatible plain data; there are no callbacks or animation timings. Animate a result in order, then compare your presentation board with `result.state.board`. Queue user inputs until your presentation catches up. Do not re-run matching, gravity or random choices in the client. `examples/event-consumer.mjs` reconstructs the board and counters using only this contract, and is exercised by the harness and simulations.

| Event | Payload and consumer behavior |
| --- | --- |
| `rejected` | Original JSON-compatible `action` (null for unrepresentable input), typed `error`; no state change. Animate a return if desired. |
| `swapped` | `move`, original `fromPiece`/`toPiece`, cumulative `moves`. Exchange the two cells. |
| `matched` | `wave`, ordered merged `groups`, each with union `cells` and original oriented `runs`. Highlight matches. |
| `specialCreated` | `wave`, `at`, `before`, replacement `piece`. Same ID, new special metadata; replace the cell. |
| `specialConverted` | Same replacement fields as creation. Color-combination conversions occur row-major before activation. |
| `combined` | `wave`, two original `pieces` with their coordinates, initial combination `targets`. These are direct targets, not the entire later chain closure. |
| `activated` | `wave`, `at`, `piece`, sorted direct `targets`, `selectedType` or null. Each special activates once per wave. A combined special's targets replace its default effect. |
| `eliminated` | `wave`, row-major `cells` including full removed pieces and coordinates. Clear all these cells simultaneously. Count non-null types toward clear objectives. |
| `scored` | `wave`, awarded `delta`, cumulative `total`, `multiplier`. Set the score to `total`. |
| `fell` | `wave`, `pieces: [{piece, from, to}]`. Apply simultaneously: clear all origins, then set all destinations; stationary pieces are omitted. Empty arrays are valid. |
| `refilled` | `wave`, `cells` with new unique pieces and final coordinates, column-major/top-to-bottom generation order. Populate the empty cells. |
| `objectives` | `progress: [{objective, current, complete}]`, evaluated after all cascades. |
| `completed` | `status` won/lost, `score`, `moves`; emitted once when a successful action ends the session. |
| `reshuffled` | `reason` deadlock/requested, complete `before` and resulting `board`, successful search `attempts`. Match animation identity by persistent piece ID. |

Within each wave: `matched` if any → creations → conversions and combination if any → activations → elimination → score → gravity → refill. Another wave follows only if automatic matches remain. Direct special swaps can have no `matched` event. Objectives are followed by completion or deadlock reshuffle, never both. A terminal board is stable and need not retain legal moves.

Activation targets can overlap, include already marked pieces, or hit a protected new special. Do not remove pieces from `activated` or `combined` targets: `eliminated` is the authoritative deduplicated list and excludes creation-wave protected specials. `specialCreated` is deliberately emitted before elimination. Pieces retain identity when converted or falling; replacements get monotonically increasing IDs.

Example ordinary wave (exact coordinates/IDs depend on the seed):

```text
swapped {move, fromPiece, toPiece, moves: 1}
matched {wave: 0, groups: [{cells: [...], runs: [...]}]}
eliminated {wave: 0, cells: [{row, col, piece: {id, type, special}}, ...]}
scored {wave: 0, delta: 30, total: 30, multiplier: 1}
fell {wave: 0, pieces: [{piece, from, to}, ...]}
refilled {wave: 0, cells: [...]}
objectives {progress: [...]}
```

Rejected actions, including resolution or reshuffle failure during a move, emit only one `rejected` event; partial success events are discarded along with partial state. Explicit `reshuffle()` failures return `events: []` and a typed error. Initial game creation and loading return a game, not an event log: initialize presentation from its state. To record an exact replay, retain an initial serialized state plus actions and engine version; events alone do not carry RNG state.
