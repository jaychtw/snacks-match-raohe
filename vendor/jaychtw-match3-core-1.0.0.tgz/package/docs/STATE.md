# Saved state v1

`game.serialize()` exports JSON; `game.exportState()` exports the equivalent detached object. `loadGame` accepts either. The engine does not read or write localStorage, files or cloud services. The consumer chooses storage, handles access errors and retains its last valid save when validation fails.

| Field | Meaning |
| --- | --- |
| `version` | Literal 1; incompatible layouts are rejected. |
| `config` | Complete normalized configuration including rules, scoring, objectives and safety budgets. |
| `board` | Rows of pieces `{id, type, special}`; one piece per cell, no holes. |
| `rng` | Nonzero unsigned 32-bit xorshift generator state. |
| `nextId` | Positive safe integer greater than every existing piece ID. |
| `moves`, `score` | Nonnegative safe integer cumulative counters. |
| `cleared` | Exactly one nonnegative safe integer counter per configured type. |
| `status` | playing/won/lost; must agree with objectives and move limit. |

Piece IDs are unique positive safe integers. Ordinary, horizontal, vertical and bomb pieces have a configured string type. `color` specials are type-neutral (`type: null`). Ordinary pieces have `special: null`. Conversion retains ID; refill assigns fresh IDs. Consumers must not treat type identifiers as localized labels or visual assets.

The [state JSON Schema](../schemas/state.schema.json) describes shape. Runtime `validateState` additionally enforces dimensions, configured type membership, unique IDs, counter bounds, special/type consistency, resolved configuration completeness, absence of automatic matches and status consistency. Stable deadlocked boards are accepted so callers can request recovery. Loader validation checks integrity, not authenticity: consumers requiring anti-cheat must authenticate their own saves.

Loading corrupted/unsupported data throws `EngineError` with `code: 'INVALID_STATE'`; no existing game is modified. Config errors at game creation throw `INVALID_CONFIG`. Creation can throw `GENERATION_LIMIT`. Player-action failures return a discriminated `Result` rather than throwing for expected gameplay errors. Programming errors are not disguised as successful turns.

Recoverable result codes:

| Code | Meaning / action |
| --- | --- |
| `INVALID_ACTION` | Malformed or out-of-bounds coordinates; correct the action. |
| `NOT_ADJACENT` | Same, diagonal or separated cells; choose orthogonal neighbors. |
| `NO_MATCH` | No immediate match involving a swapped cell or enabled special interaction. |
| `GAME_OVER` | Create/reload another session to play again. |
| `RESOLUTION_LIMIT` | Safety budget or safe-integer limit exceeded; prior state retained. Choose another action or explicitly configure larger budgets in a new session. |
| `UNSHUFFLABLE` | Proven insufficient type multiplicities for any match, with no enabled special-swap escape. Choose another action or restart. |
| `SHUFFLE_LIMIT` | Seeded permutation budget exhausted; a valid permutation may still exist. Prior state and RNG retained; unchanged retries repeat the same failure. |

Changes that alter public API or persisted-state compatibility require a semantic major version and explicit migration notes. The first release has no legacy migration. Deterministic replay should pin the exact package version/artifact because a rule or RNG change can change events even if the JSON shape remains compatible.
