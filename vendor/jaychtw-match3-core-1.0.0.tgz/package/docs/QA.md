# QA report — 1.0.0 pre-push review

Date: 2026-10-24 (Asia/Taipei). Repository began empty, on an unborn `work` branch. This report records local evidence before the first source push, not a live view of GitHub. The initial local artifact had 108 passing tests; the EDD review added four regression tests. For actual commit, tag and hosted CI evidence, inspect repository refs, the exact commit's Actions run, and `verify:release` output. Checksums are kept outside the package to avoid a self-referential archive hash.

## Reproduction

```sh
cd /workspace/match3-core
npm ci --ignore-scripts --cache /workspace/.npm-cache --no-audit --no-fund
npm run build
npm test
npm run demo
npm run verify:release -- /tmp/match3-verified-release
npm pack --cache /workspace/.npm-cache --pack-destination /workspace/match3-artifacts/v1.0.0
```

Runtime: Node 24.19.0, npm 11.9.0, Linux x86_64. TypeScript 5.9.3 is pinned in `package-lock.json`. No runtime package dependencies. npm cache is explicitly writable in this cloud environment; no verification was disabled.

## Results

| Check | Result |
| --- | --- |
| Strict TypeScript/declaration build | Pass |
| Node automated suite | 112 passed, 0 failed, 0 skipped/cancelled/todo |
| Seeded simulation | 60 seeds, 1,200 attempted actions; 1,155 committed moves; 45 typed recoverable failures with exact rollback; 1,930 resolution waves; 74 successful deadlock reshuffles |
| Special combinations | All 10 unordered pairs in both orientations, exact target checks; all pairs also tested through public API and event projection |
| Exact replay | State and ordered event equality across simulations and save/restore continuation |
| Consumer harness | Pass: creates, enumerates actions, applies moves, projects ordered events into a board, verifies counters, saves/restores, continues identically |
| JSON schemas | Draft-07 schema validity and generated config/state fixtures checked with Python jsonschema; relational validation tested through runtime loader |
| Standard pin | Local UGDS file byte-compared with the exact pinned checkout |

The simulation's recoverable failures occur on small boards whose refill cannot be completed with a valid reshuffle under the preserved-piece rules/budget. They are asserted error outcomes, not failed tests, skipped moves reported as successes, or partially committed sessions. Safety-limit, invalid-save and invalid-input tests also require explicit failure outcomes. The suite completes in about one second on this cloud host; that is not a hardware-independent performance guarantee.

## Artifact and integration

Local release directory: `/workspace/match3-artifacts/v1.0.0/`. Artifact: `jaychtw-match3-core-1.0.0.tgz`. Integrity file: `SHA256SUMS`. The artifact includes JavaScript, declarations, source maps and source, schemas, documentation, unchanged EDD/UGDS references, and the minimal harness. No dependencies or credential files are bundled. Package installation and harness checks are reported in the adjacent external `VALIDATION.txt` after packaging.

The GitHub Actions workflow runs build/tests, the harness and two independent committed-source package builds/install/type checks on Node 22 and 24, then uploads tarballs and evidence. Node 22 and hosted Actions were not run as part of this pre-push local review. A configured workflow is not a passing hosted CI run. The release tag requires subsequently observed hosted success for the intended commit.

## Unverified or excluded

- Actual browser execution, physical-device performance, independent first-time player testing and Shape Match integration: **Not Verified**.
- Maximum supported input size is not a responsiveness guarantee; large boards, repeated permutations and large wave budgets can block the caller. Use a worker for consumer UI isolation.
- No screenshots, viewport/language matrix, visual-direction approval or accessibility audit: **Not Applicable** to this headless artifact under EDD §13. These remain requirements for consuming games.
- No hosted deployment, live URL or production game verification. No product-level acceptance claimed.
- No exhaustive solver for all possible multisets; `SHUFFLE_LIMIT` is a search-budget error and is not proof of impossibility.
- No obstacles/immutable cells, alternate gravity, portals or custom scripts; these are explicitly outside v1 scope.

See [acceptance matrix](ACCEPTANCE.md) for every governing UGDS requirement and the remaining EDD gates. The local artifact supports integration work; hosted CI and a real Shape Match integration are still required before claiming the EDD's complete technical acceptance.
