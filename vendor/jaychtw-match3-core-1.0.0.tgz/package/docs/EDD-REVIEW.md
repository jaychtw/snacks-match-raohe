# Review against EDD v0.1.0

Reviewed 2026-10-24 (Asia/Taipei), before the first source push. Baselines: unchanged `EDD.md` and UGDS 1.0.0 commit `d5c6696efdd6efc028118600466db44aecae0c9b`. Evidence is in the named source/tests and reproducible commands below. This records an engineering review, not Shape Match product acceptance.

| EDD section | Assessment / evidence |
| --- | --- |
| 1–2 Purpose, boundaries | Headless TypeScript ESM; no runtime dependencies, themes, DOM, network or storage. Node >=22, browser ES2022/structuredClone target. Actual browser execution remains unverified. |
| 3.1 Board | 8×8/six types by default; dimensions/types validated. Supported bounds are explicit (3–32 rows/columns, 3–64 safe string types). Rectangular downward-only board. |
| 3.2 Swaps | Bounds, orthogonal adjacency, immediate swapped-cell match or enabled special interaction. Rejection events and transactional snapshots preserve board, RNG and moves. Both action directions enumerated because anchors can differ. |
| 3.3 Matches | Horizontal/vertical runs; transitive overlapping groups; five-or-more > intersection > four; at most one special/group; deterministic ordinary-cell anchors. Matching, intersections, overlap and tie-break tests. |
| 3.4–3.5 Specials | Four special kinds, all ten unordered special pairs plus each ordinary/special interaction. Match/swap/chain activation, protected creation wave, activation and scoring deduplication. Exact targets tested in both pair orientations; public-API event projection covers all pairs. |
| 4 Turn resolution | Whole move/cascades resolve synchronously in private state; atomic commit or typed failure. Per-wave scoring event precedes gravity/refill; objective/terminal evaluation follows all waves, then live-deadlock check. This makes the EDD's delegated internal ordering explicit. |
| 5 Determinism | Seed hashing and xorshift32; RNG persisted. No Math.random/time/render dependence. Multi-seed tests compare states and ordered events, including failure rollback and restored continuation. |
| 6 Initialization/reshuffle | Bounded stable playable generation; seeded identity/special-preserving permutation search. No immutable cells exist in v1. Failed search never returns a deadlock as success or regenerates pieces silently. |
| 7 Objectives/scoring | Score, one-or-more-type clear targets, conjunctive objectives and move limits. Authoritative eliminations drive clear counters; configurable points/activation bonus/cascade multiplier. Win precedes last-move loss. |
| 8 API/events | Factories, loader, board snapshots, legal actions, move application, objectives/status, export/serialize. Typed discriminated events include identities, coordinates, effects, fall/refill, score and completion. Consumer harness reconstructs the result without matching logic. |
| 9 Integrity/errors | Strict config/state checks, unique occupancy/IDs, RNG/counters, special metadata and stable-turn validation. Expected action/limit errors return typed results; create/load throw typed errors. Failed moves do not partially mutate state. |
| 10 Configuration | Dimensions, types, creation/swap toggles, match length, radii, scoring, objectives, limits, seed and safety budgets. No arbitrary effect scripting. |
| 11 Tests | Unit tests plus generated multi-seed invariant/simulation tests, exact replay and consumer integration. Simulation uses seeded generators and plain Node assertions rather than a third-party property-testing framework. |
| 12 Repository/release | Source, tests, API/rules/event/state docs, JSON schemas, EDD/UGDS, history and version notes present. CI now includes two clean committed-source builds, byte-identical package verification, independent package install/type checks and uploaded evidence. Hosted result/tag must be verified separately. |
| 13 UGDS | Immutable unchanged standard retained; per-ID applicability recorded in `ACCEPTANCE.md`. No waiver inferred. Game presentation belongs to consumers as explicitly scoped by EDD. |
| 14 Exclusions | No UI/art/audio, accounts, network multiplayer, editor, obstacles/portals/alternate gravity or speculative plugin system. |
| 15 Acceptance | Local engine/harness checks pass. Hosted CI and committed-source reproducibility are release gates. Shape Match integration and product acceptance remain separate and unverified. |

## Deviations, clarifications and remaining gaps

1. **Bounded search is not an exhaustive solvability proof.** `SHUFFLE_LIMIT` reports budget exhaustion even when a valid permutation may exist; `UNSHUFFLABLE` is used only for a proven insufficient-count case. Both are typed recoverable errors, preserve the original session and never hang. Small-board actions can fail after refill; legality only establishes the immediate swap. This is a documented implementation limitation relative to an ideal always-successful reshuffler, not permission to alter piece attributes or weaken invariants.
2. **Creation-wave protection is stronger than the minimum wording.** EDD forbids activation solely because of creation; this default protects a new special from every effect for that wave. It becomes eligible in later waves. That delegated rule choice is documented and tested, rather than left to iteration order.
3. **Scoring is emitted per wave.** EDD §4 lists scoring near end-of-turn; the implementation records each wave's authoritative removal/activation award before gravity, then evaluates objectives/termination after cascades. Final scoring and event order are deterministic and specified. Consumers must follow the documented event contract.
4. **Supported input bounds are narrower than arbitrary rectangles/identifiers.** Dimensions 3–32, match length 3–5, 3–64 safe identifiers and documented integer budgets are validated. EDD permits configuration validation and excludes unsupported board topology; these are disclosed limits, not silently accepted unsupported configurations.
5. **Browser/device and consumer acceptance are not established by Node tests.** Actual browser runtime, physical-device performance, accessibility/visual presentation, independent player testing and Shape Match integration remain unverified or consumer-scoped as stated in `ACCEPTANCE.md`.
6. **Distribution is an ESM tarball, not a published npm registry package.** npm publishing is optional in the EDD. Git dependencies must build first; the verified tarball includes all required generated output and declarations. No CommonJS target is supplied.

No missing mandatory engine mechanic was found in this review. Do not equate this finding with completion of hosted CI, tag publication or Shape Match acceptance; those require their own evidence.

## Review fixes

- `RULES.md` now explicitly states equal-length run tie-breaking (first row-major start, horizontal before vertical on a shared start), transitive groups and one-special-per-group precedence.
- Validation now rejects sparse type/objective arrays, non-plain configuration objects and inherited piece metadata with typed errors. Regression tests cover these cases.
- Four review tests were added; the local suite now has **112 passing tests**, zero failures/skips. The seeded simulation still exercises 1,200 actions (1,155 commits, 45 verified recoverable failures), 1,930 waves and 74 deadlock reshuffles.

## Rules completeness confirmation

`RULES.md` contains all `4 × 5 / 2 = 10` unordered special pairs: H/H, H/V, V/V, H/bomb, V/bomb, bomb/bomb, same-type/H, same-type/V, same-type/bomb, same-type/same-type. The symmetric-table rule covers reverse operand order. Ordinary partners, indirect same-type targeting, chain ordering, clipping, conversion orientations and radii are specified too.

Overlapping precedence specifies transitive grouping, group/run ordering, five-or-more/intersection/four priority, disabled-rule fallback, equal-run orientation, one special/group, ordinary-only anchor eligibility, swapped destination/source/row-major preference, and no eligible anchor fallback. Creation versus existing-special activation and complete wave ordering are also explicit.

## Reproduce release checks

After committing all files, from the checkout:

```sh
npm ci --ignore-scripts --cache /tmp/match3-release-npm-cache
npm test
npm run demo
npm run verify:release -- /tmp/match3-verified-release
```

`verify:release` requires a clean working tree, archives the exact HEAD twice into independent temporary directories, installs the lockfile and builds/packages independently, compares SHA-256, installs a tarball in a third consumer, runs its harness, and type-checks its public exports. It does not create a worktree or depend on retained `dist/`. The output records the actual commit and tool versions. Hosted CI performs these checks for Node 22 and 24. Tag `v1.0.0` only after the exact intended commit's hosted checks and package verification pass.
