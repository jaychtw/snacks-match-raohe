# Deterministic rules, v1

This specification precedes the implementation. Coordinates are zero-based; row-major order means row, then column. A turn either commits its complete result or leaves the prior state, including its RNG, untouched.

## Matches and order

Runs contain at least `matchLength` equal, non-neutral types. Intersecting runs merge transitively into one group. Groups are ordered by their first row-major cell. A group creates at most one special: a run of five or more takes priority over an intersection, which takes priority over a run of four. Disabling a creation rule allows the next applicable rule. Horizontal and vertical four-runs produce their respective line orientation. Other members are eliminated.

Within each group, runs are sorted by their first row-major cell, with horizontal before vertical when those first cells coincide. If several equally longest runs qualify for line creation (for example with intersection creation disabled), the first run in this order determines orientation. Five-or-more and intersection classification never create additional specials from subordinate runs. Parallel disjoint runs form separate groups; runs merge only when they share a cell, including transitive intersections. Classification is independent of the order in which cells are cleared.

Creation anchors must be ordinary matched pieces: prefer the swap destination, then source, then the first row-major eligible cell. If no ordinary cell exists, no new special is made. Newly created specials are protected throughout that resolution wave, including from other effects, and become eligible in later cascades. Existing specials in matches activate. Initial matches are sorted and classified before effects run; created pieces are placed before elimination.

Effect targets and activation queues are processed in row-major order. Every piece is removed, scored and activated at most once per wave. Effects hitting specials enqueue their activation. A neutral same-type clearer triggered indirectly selects the most frequent ordinary type; ties use configured piece-type order. It clears ordinary pieces of that type. Direct swaps select the other piece's original type, retained even if match classification subsequently makes that partner a new neutral special.

## Complete special interaction table

The table is symmetric. Centers refer to positions **after** the swap. Both original special pieces are consumed and each emits exactly one activation event. Combination effects replace their individual default effects. Other specials reached by effects activate normally.

| Pair | Default effect |
| --- | --- |
| Horizontal + horizontal | Rows and columns through both centers |
| Horizontal + vertical | Rows and columns through both centers |
| Vertical + vertical | Rows and columns through both centers |
| Horizontal + bomb | Three full rows and three full columns centered on the bomb |
| Vertical + bomb | Three full rows and three full columns centered on the bomb |
| Bomb + bomb | Union of squares of radius `2 * bombRadius` around both centers |
| Same-type + horizontal | Convert every ordinary piece of the horizontal piece's type to a line clearer, alternating horizontal/vertical in row-major order; activate these and the original line |
| Same-type + vertical | Same conversion and alternating orientations; activate these and the original line |
| Same-type + bomb | Convert every ordinary piece of the bomb's type to a bomb; activate these and the original bomb |
| Same-type + same-type | Clear the entire board, triggering other specials |

Line+bomb width is configurable using `comboLineRadius` (default 1). All areas clip at board edges. A line or bomb swapped with an ordinary piece activates at its destination and consumes itself; its partner is removed only if hit. Same-type + ordinary consumes both and all ordinary pieces of the partner's type. Special swaps can be disabled; then a swap must form a match and specials activate through matches/effects only.

## Turn and scoring

A valid swap consumes exactly one move. Swap → match classification → creation → combination/activation closure → elimination → score → gravity → replenishment repeats until stable. Gravity preserves vertical order and emits old/new coordinates. Refills run columns left-to-right, empty cells top-to-bottom. A turn has at most `maxWaves` resolution waves; exhaustion is an explicit transactional failure.

Each eliminated piece earns `piecePoints` (default 10); each activated special additionally earns `specialBonus` (default 20). Wave zero has multiplier 1; wave n has multiplier `1 + n * cascadeStep` (default step 1). Created specials are not eliminated or scored in their creation wave. Score events state the awarded delta and running total. Clear objectives count eliminated pieces with non-null underlying types, including typed specials. Neutral clearers count toward score but not type objectives.

Objectives are conjunctive. With no objectives a session is open-ended unless a move limit is configured. Victory is evaluated before move-limit defeat. Terminal boards are stable and are not reshuffled. Live deadlocks reshuffle by a seeded Fisher–Yates permutation of the existing pieces, preserving IDs and special metadata. Immediate matches are forbidden. Bounded search exhaustion reports `SHUFFLE_LIMIT`, never a claim of mathematical impossibility. A provably impossible multiset reports `UNSHUFFLABLE`. Either failure rolls back the entire operation. Generation is bounded too and never returns a deadlocked board as success.

## Scope and standard

UGDS v1.0.0 reference: [jaychtw/game-development-standards](https://github.com/jaychtw/game-development-standards/tree/d5c6696efdd6efc028118600466db44aecae0c9b), commit `d5c6696efdd6efc028118600466db44aecae0c9b`. The unchanged standard is retained in `UGDS-v1.0.0.md` and was read before engine implementation. The EDD §13 explicitly assigns rendering, art, touch UI, accessibility presentation and localization to consumers. Engineering, state integrity, determinism, QA, dependency, versioning and truthful reporting apply here. There is no known unresolved applicability conflict; this is a headless library, not a delivered game. See `ACCEPTANCE.md` for requirement statuses. Shape Match integration and a successful hosted CI run remain separate acceptance gates.
