# Match3 Core

Headless, deterministic TypeScript match-3 engine. Version 1.0.0 implements the [EDD](docs/EDD.md). No runtime dependencies, DOM, timers, network requests, rendering, or theme-specific logic.

## Develop

Node.js 22+ and npm are required. Use the existing isolated checkout; no worktree is needed.

```sh
cd /workspace/match3-core
npm ci --cache /workspace/.npm-cache
npm test
npm run demo
npm run verify:release -- /tmp/match3-verified-release
npm pack --cache /workspace/.npm-cache
```

Outside the cloud workspace, use your checkout directory and omit the cache override. `npm test` builds and runs mechanics, validation, deterministic simulations and consumer-event projection checks. The demo creates a game, lists moves, applies actions, consumes events, checks state, and restores/replays a saved session. No server or credentials are needed. Generated `dist/` files are ignored and included in the npm tarball. `verify:release` requires committed source and a clean working tree: it independently builds/packages HEAD twice, compares SHA-256, then installs and type-checks an external consumer. Its output records the exact source commit and toolchain.

## Consume

Install the generated `jaychtw-match3-core-1.0.0.tgz` in a consumer (`npm install /path/to/jaychtw-match3-core-1.0.0.tgz`). Preserve its SHA-256 alongside the dependency lockfile for reproducible integration. This package is ESM; npm publication is optional and has not occurred. For a Git checkout dependency, build the package before consuming it, or use the packed artifact.

```ts
import { createGame, loadGame } from '@jaychtw/match3-core';

const game = createGame({
  rows: 8, cols: 8,
  pieceTypes: ['a', 'b', 'c', 'd', 'e', 'f'],
  objectives: [{ kind: 'score', target: 1000 }],
  moveLimit: 20,
}, 'level-1');

const move = game.listLegalMoves()[0];
if (move) {
  const result = game.applyMove(move);
  if (result.ok) {
    // Hand these ordered events to your presentation layer.
    for (const event of result.events) console.log(event.type);
  } else {
    console.log(result.error.code); // localize this code in your game
  }
}
const restored = loadGame(game.serialize());
console.log(restored.state.status);
```

The engine runs in modern browsers supporting ES2022 modules and `structuredClone`, directly from `dist/index.js` or through a bundler. Node APIs are used only by tests and examples.

## API

| API | Contract |
| --- | --- |
| `createGame(config?, seed?)` | Stable, playable initial board. Defaults to seed 1; throws typed `EngineError` for invalid config or bounded generation exhaustion. |
| `loadGame(jsonOrObject)` | Validate and restore a complete version-1 state; throws `INVALID_STATE` on corruption. Stable deadlocked states can be loaded for explicit recovery. |
| `resolveConfig(config?)` | Validate and copy configuration, filling defaults. |
| `validateState(unknown)` | Validate and return an independent saved-state copy. |
| `game.state`, `inspectBoard()`, `exportState()` | Independent snapshots; changing them cannot mutate the game. |
| `listLegalMoves()`, `isLegalMove(action)` | Immediate swap legality; terminal sessions have no legal moves. Does not promise subsequent bounded resolution or reshuffling succeeds. |
| `applyMove(action)` | `{ok, state, events}`; failure also has `{error: {code, message}}`. All failures are transactional, including RNG and counters. |
| `reshuffle()` | Transactional seeded permutation preserving all pieces, IDs and special metadata. Does not consume a move. |
| `objectives()` | Current values and completion flags; multiple objectives are conjunctive. |
| `serialize()` | JSON state including normalized config, board, RNG and counters for exact replay. |
| `detectMatches(board, matchLength?)` | Pure inspection utility for a well-formed typed board; returns ordered merged groups and their runs. |

`Game`, public types and `EngineError` are exported. `Game`'s constructor validates its supplied state, but factories are recommended. Coordinates are zero-based. All committed turns expose full stable boards. Configuration is fixed per session; load a complete validated state to construct an authored starting board.

Legal moves include both directions for each legal adjacent pair: reversing the direction can change the preferred special-creation anchor. Enumeration is row-major, right neighbor then down neighbor, forward then reverse.

## Configuration

Input fields are optional; unknown fields are rejected. See [JSON Schema](schemas/config.schema.json), exported `Config`/`ResolvedConfig` types and [deterministic rules](docs/RULES.md).

| Setting | Default / valid range |
| --- | --- |
| `rows`, `cols` | 8; integers 3–32 |
| `pieceTypes` | a–f; 3–64 unique safe identifiers, 1–64 ASCII letters/digits/underscore/hyphen; prototype-related names reserved |
| `rules.matchLength` | 3; 3–5, must fit at least one board dimension |
| `rules.createFour`, `createFive`, `createIntersection` | true |
| `rules.specialSwaps` | true; any special can activate by an adjacent swap |
| `rules.bombRadius` | 1; 1–8 |
| `rules.comboLineRadius` | 1; 1–8 |
| `scoring.piecePoints`, `specialBonus`, `cascadeStep` | 10, 20, 1; integer 0–1,000,000 |
| `objectives` | []; score or clear-types objectives, positive safe integer targets, at most 100 |
| `moveLimit` | null (unlimited); or 1–1,000,000 |
| `maxWaves` | 100; 1–10,000 |
| `shuffleAttempts` | 1,000; 1–10,000 |
| `generationAttempts` | 100; 1–10,000 |

`seed` is a finite number or string passed to `createGame`, default 1. Its string representation is hashed with FNV-1a-style 32-bit arithmetic; xorshift32 supplies subsequent randomness. Numeric 1 and string "1" intentionally produce the same sequence. Exact reproducibility requires the same engine/rules version, config, state and actions. New games need at least one legal move; generation exhausts a configurable finite budget instead of looping forever.

## Rules, events and persistence

- [Complete special interaction table and resolution order](docs/RULES.md)
- [Event log contract and presentation integration](docs/EVENTS.md)
- [State format and recovery](docs/STATE.md)
- [Minimal event consumer](examples/event-consumer.mjs) and [CLI harness](examples/consumer.mjs)
- [UGDS applicability and acceptance](docs/ACCEPTANCE.md), [QA evidence](docs/QA.md), [release notes](CHANGELOG.md)
- [EDD v0.1.0 review, deviations and rules completeness](docs/EDD-REVIEW.md)

## Limits

No obstacles, immutable tiles, portals, alternate gravity, arbitrary effect scripting, UI, persistence storage or authored-level editor. Reshuffling preserves all current pieces; there are no immutable board elements in this release. Configured budgets can reject an otherwise legal move. Small boards can refill into unshufflable multisets; callers receive `UNSHUFFLABLE` with the original session intact and may choose another move or restart. `SHUFFLE_LIMIT` means the bounded search was exhausted, not mathematical impossibility. Uniform multisets can also be impossible to arrange without matches and will exhaust that budget.

Performance is validated in Node, not on physical devices; 32×32 is an input bound, not a mobile performance guarantee. Large boards and high search/wave budgets can block a UI thread; consumers can run the synchronous engine in a Web Worker. Shape Match integration and final product acceptance are outstanding. Verify hosted CI against the exact commit on the repository's [Actions page](https://github.com/jaychtw/match3-core/actions); a configured workflow is not evidence of a passing run. A `v1.0.0` tag is gated on hosted checks and reproducible committed-source packaging.
