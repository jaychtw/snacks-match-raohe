# Changelog

## 1.0.0 — 2026-10-24

Initial local release implementing EDD 0.1.0: deterministic initialization, matching and overlap classification, four special kinds and all ten pair interactions, transactional turn resolution, cascades, scoring/objectives, legal moves, bounded identity-preserving reshuffles, validated state persistence and complete presentation events.

Includes strict TypeScript declarations, configuration/state schemas, mechanics and simulation tests, event-projection consumer harness, and GitHub Actions configuration for Node 22/24. Zero runtime dependencies. EDD review adds sparse-array/prototype validation hardening, explicit overlapping-run tie-break rules, and committed-source reproducible package/consumer checks.

State format: version 1. No earlier state format is supported. Browser consumers require ES2022 and `structuredClone`. The npm tarball is the integration artifact; npm registry publishing is optional. Tagging requires verified hosted CI and reproducible packaging at the intended commit. Shape Match integration remains unverified. See `docs/QA.md` and `docs/EDD-REVIEW.md` for evidence and limitations.
