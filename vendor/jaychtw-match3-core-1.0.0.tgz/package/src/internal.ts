// Shared coordinate helpers; never part of the package export surface.
export { at, key, order, positions } from './board.js';
import type { Position } from './types.js';
export const copyPosition = (p: Position): Position => ({row:p.row,col:p.col});
