import { copy, EngineError, integer, record, resolveConfig } from './config.js';
import { detectMatches } from './board.js';
import type { Config, GameState, Objective, Status } from './types.js';

export function objectiveProgress(state: GameState): { objective: Objective; current: number; complete: boolean }[] {
  return state.config.objectives.map(objective => {
    const current = objective.kind === 'score' ? state.score : objective.types.reduce((sum,t)=>sum+state.cleared[t]!,0);
    return {objective:copy(objective),current,complete:current>=objective.target};
  });
}
export function statusOf(state: GameState): Status {
  if (state.config.objectives.length && objectiveProgress(state).every(o=>o.complete)) return 'won';
  return state.config.moveLimit !== null && state.moves >= state.config.moveLimit ? 'lost' : 'playing';
}
export function validateState(input: unknown): GameState {
  const fail = (message: string): never => { throw new EngineError('INVALID_STATE',message); };
  if (!record(input)) return fail('Saved state must be an object');
  const fields = ['version','config','board','rng','nextId','moves','score','cleared','status'];
  if (Object.keys(input).length !== fields.length || !fields.every(k=>Object.hasOwn(input,k))) fail('Unexpected or missing saved state fields');
  if (input.version !== 1) fail('Unsupported saved state version');
  let config;
  try { config = resolveConfig(input.config as Config); } catch { return fail('Invalid saved configuration'); }
  if (!record(input.config) || !Object.keys(config).every(k=>Object.hasOwn(input.config as object,k)) || !record(input.config.rules) || !Object.keys(config.rules).every(k=>Object.hasOwn((input.config as Record<string, unknown>).rules as object,k)) || !record(input.config.scoring) || !Object.keys(config.scoring).every(k=>Object.hasOwn((input.config as Record<string, unknown>).scoring as object,k))) fail('Saved configuration must be fully resolved');
  if (!integer(input.rng,1,0xffffffff) || !integer(input.nextId,1,Number.MAX_SAFE_INTEGER) || !integer(input.moves,0,Number.MAX_SAFE_INTEGER) || !integer(input.score,0,Number.MAX_SAFE_INTEGER)) fail('Invalid random state or counters');
  if (config.moveLimit !== null && (input.moves as number)>config.moveLimit) fail('Move count exceeds limit');
  if (!record(input.cleared) || Object.keys(input.cleared).length !== config.pieceTypes.length || !config.pieceTypes.every(t=>Object.hasOwn(input.cleared as object,t) && integer((input.cleared as Record<string, unknown>)[t],0,Number.MAX_SAFE_INTEGER))) fail('Invalid cleared counters');
  if (!Array.isArray(input.board) || input.board.length !== config.rows) fail('Invalid board height');
  const ids = new Set<number>();
  for (const row of input.board as unknown[]) {
    if (!Array.isArray(row) || row.length !== config.cols) return fail('Invalid board width');
    for (const piece of row) {
      if (!record(piece) || Object.keys(piece).length!==3 || !integer(piece.id,1,(input.nextId as number)-1) || ids.has(piece.id)) return fail('Invalid or duplicate piece ID');
      ids.add(piece.id);
      if (![null,'horizontal','vertical','bomb','color'].includes(piece.special as string | null)) fail('Unknown special kind');
      if (piece.special==='color' ? piece.type!==null : typeof piece.type!=='string' || !config.pieceTypes.includes(piece.type)) fail('Inconsistent piece type and special metadata');
    }
  }
  const state = copy(input) as unknown as GameState;
  if (detectMatches(state.board,config.rules.matchLength).length) fail('Saved board contains unresolved matches');
  if (state.status !== statusOf(state)) fail('Inconsistent terminal status');
  if (Object.values(state.cleared).reduce((a,b)=>a+b,0)>Number.MAX_SAFE_INTEGER) fail('Clear counters overflow');
  return state;
}
