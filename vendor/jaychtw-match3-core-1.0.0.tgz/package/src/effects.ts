import { at, copyPosition, key, order, positions } from './internal.js';
import { creation, random } from './board.js';
import { copy, EngineError } from './config.js';
import type { Cell, GameEvent, GameState, Match, Move, Piece, Position } from './types.js';

function area(state: GameState, center: Position, radius: number): Position[] {
  return positions(state.config).filter(p=>Math.abs(p.row-center.row)<=radius && Math.abs(p.col-center.col)<=radius);
}
function cross(state: GameState, center: Position, radius = 0): Position[] {
  return positions(state.config).filter(p=>Math.abs(p.row-center.row)<=radius || Math.abs(p.col-center.col)<=radius);
}
function selectedType(state: GameState): string {
  const counts = state.config.pieceTypes.map(type=>({type,count:state.board.flat().filter(p=>p.special===null && p.type===type).length}));
  return counts.reduce((a,b)=>b.count>a.count ? b:a).type;
}
function targets(state: GameState, center: Position, piece: Piece, selected: string | null): Position[] {
  switch (piece.special) {
    case 'horizontal': return positions(state.config).filter(p=>p.row===center.row);
    case 'vertical': return positions(state.config).filter(p=>p.col===center.col);
    case 'bomb': return area(state,center,state.config.rules.bombRadius);
    case 'color': return positions(state.config).filter(p=>at(state.board,p).special===null && at(state.board,p).type===selected);
    default: return [];
  }
}
export function resolveWave(state: GameState, groups: Match[], wave: number, events: GameEvent[], specialMove?: Move): void {
  const protectedIds = new Set<number>(), eliminated = new Map<string,Position>(), activated = new Set<number>();
  const overrides = new Map<number,{targets:Position[];selected:string|null}>();
  // Match creation can change a swapped ordinary piece into a neutral clearer.
  // Direct color selection must retain the type chosen by the original swap.
  const originalSwapTypes = new Map(specialMove ? [specialMove.from,specialMove.to].map(p=>[key(p),at(state.board,p).type] as const):[]);
  if (groups.length) events.push({type:'matched',wave,groups:copy(groups)});
  for (const group of groups) {
    const created = creation(group,state,specialMove ? [specialMove.to,specialMove.from]:[]);
    if (created) {
      const before = copy(at(state.board,created.at));
      const piece: Piece = {...before,special:created.special,type:created.special==='color' ? null:before.type};
      state.board[created.at.row]![created.at.col] = piece;
      protectedIds.add(piece.id);
      events.push({type:'specialCreated',wave,at:created.at,before,piece:copy(piece)});
    }
  }
  const mark = (p: Position): void => { if (!protectedIds.has(at(state.board,p).id)) eliminated.set(key(p),p); };
  for (const group of groups) for (const p of group.cells) mark(p);
  if (specialMove && state.config.rules.specialSwaps) {
    const centers = [specialMove.from,specialMove.to];
    const specials = centers.filter(p=>at(state.board,p).special && !protectedIds.has(at(state.board,p).id));
    // Only pre-existing swapped specials count as direct triggers. Creations are protected above.
    for (const p of specials) mark(p);
    if (specials.length===2) {
      const pieces: Cell[] = specials.map(p=>({...p,piece:copy(at(state.board,p))}));
      const color = specials.find(p=>at(state.board,p).special==='color');
      if (color) {
        const other = specials.find(p=>key(p)!==key(color))!;
        const partner = at(state.board,other);
        if (partner.special==='color') {
          for (const p of specials) overrides.set(at(state.board,p).id,{targets:positions(state.config),selected:null});
        } else {
          const converted: Position[] = [];
          for (const p of positions(state.config)) {
            const before = at(state.board,p);
            if (before.special!==null || before.type!==partner.type || protectedIds.has(before.id)) continue;
            const special = partner.special==='bomb' ? 'bomb' : converted.length%2===0 ? 'horizontal':'vertical';
            const piece = {...before,special} as Piece;
            state.board[p.row]![p.col]=piece;
            converted.push(p);
            events.push({type:'specialConverted',wave,at:p,before:copy(before),piece:copy(piece)});
          }
          overrides.set(at(state.board,color).id,{targets:converted,selected:partner.type});
          overrides.set(partner.id,{targets:targets(state,other,partner,partner.type),selected:null});
        }
      } else {
        const bombs = specials.filter(p=>at(state.board,p).special==='bomb');
        const affected = bombs.length===2 ? specials.flatMap(p=>area(state,p,2*state.config.rules.bombRadius)) : bombs.length===1 ? cross(state,bombs[0]!,state.config.rules.comboLineRadius) : specials.flatMap(p=>cross(state,p));
        const unique = [...new Map(affected.map(p=>[key(p),p])).values()].sort(order);
        for (const p of specials) overrides.set(at(state.board,p).id,{targets:unique,selected:null});
      }
      const combinedTargets = [...new Map([...overrides.values()].flatMap(v=>v.targets).map(p=>[key(p),p])).values()].sort(order);
      events.push({type:'combined',wave,pieces,targets:copy(combinedTargets)});
    } else if (specials.length===1 && at(state.board,specials[0]!).special==='color') {
      const color = specials[0]!, other = centers.find(p=>key(p)!==key(color))!;
      const type = originalSwapTypes.get(key(other)) ?? null;
      overrides.set(at(state.board,color).id,{targets:[other,...targets(state,color,at(state.board,color),type)],selected:type});
    }
  }
  while (true) {
    const next = [...eliminated.values()].sort(order).find(p=>at(state.board,p).special && !activated.has(at(state.board,p).id));
    if (!next) break;
    const piece = at(state.board,next);
    activated.add(piece.id);
    const override = overrides.get(piece.id);
    const selected = override ? override.selected : piece.special==='color' ? selectedType(state):null;
    const affected = override?.targets ?? targets(state,next,piece,selected);
    const unique = [...new Map(affected.map(p=>[key(p),p])).values()].sort(order);
    events.push({type:'activated',wave,at:copyPosition(next),piece:copy(piece),targets:copy(unique),selectedType:selected});
    for (const p of unique) mark(p);
  }
  const cells = [...eliminated.values()].sort(order).map(p=>({...p,piece:copy(at(state.board,p))}));
  if (!cells.length) throw new EngineError('RESOLUTION_LIMIT','Resolution wave made no progress');
  for (const cell of cells) if (cell.piece.type!==null) {
    const total=state.cleared[cell.piece.type]!+1;
    if (!Number.isSafeInteger(total)) throw new EngineError('RESOLUTION_LIMIT','Clear counter overflow');
    state.cleared[cell.piece.type]=total;
  }
  if (!Number.isSafeInteger(Object.values(state.cleared).reduce((a,b)=>a+b,0))) throw new EngineError('RESOLUTION_LIMIT','Clear counter total overflow');
  events.push({type:'eliminated',wave,cells});
  const multiplier = 1+wave*state.config.scoring.cascadeStep;
  const delta = (cells.length*state.config.scoring.piecePoints+activated.size*state.config.scoring.specialBonus)*multiplier;
  if (!Number.isSafeInteger(delta+state.score)) throw new EngineError('RESOLUTION_LIMIT','Score overflow');
  state.score += delta;
  events.push({type:'scored',wave,delta,total:state.score,multiplier});
  const fallen: Extract<GameEvent,{type:'fell'}>['pieces'] = [], refill: Cell[] = [];
  for (let col=0; col<state.config.cols; col++) {
    const survivors: {piece:Piece;row:number}[] = [];
    for (let row=0;row<state.config.rows;row++) if (!eliminated.has(key({row,col}))) survivors.push({piece:state.board[row]![col]!,row});
    const empty = state.config.rows-survivors.length;
    survivors.forEach((entry,i)=>{
      const row = empty+i;
      state.board[row]![col] = entry.piece;
      if (entry.row!==row) fallen.push({piece:copy(entry.piece),from:{row:entry.row,col},to:{row,col}});
    });
    for (let row=0;row<empty;row++) {
      if (!Number.isSafeInteger(state.nextId+1)) throw new EngineError('RESOLUTION_LIMIT','Piece ID overflow');
      const piece: Piece = {id:state.nextId++,type:state.config.pieceTypes[Math.floor(random(state)*state.config.pieceTypes.length)]!,special:null};
      state.board[row]![col] = piece;
      refill.push({row,col,piece:copy(piece)});
    }
  }
  events.push({type:'fell',wave,pieces:fallen},{type:'refilled',wave,cells:refill});
}
