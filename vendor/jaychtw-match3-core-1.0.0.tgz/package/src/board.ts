import { EngineError, copy } from './config.js';
import type { Board, GameState, Match, Move, Piece, Position, ResolvedConfig, Special } from './types.js';

export const samePosition = (a: Position, b: Position): boolean => a.row === b.row && a.col === b.col;
export const order = (a: Position, b: Position): number => a.row - b.row || a.col - b.col;
export const key = (p: Position): string => `${p.row},${p.col}`;
export const at = (board: Board, p: Position): Piece => board[p.row]![p.col]!;
export const positions = (config: ResolvedConfig): Position[] => Array.from({length: config.rows * config.cols}, (_, i) => ({row: Math.floor(i / config.cols), col: i % config.cols}));
export function random(state: { rng: number }): number {
  let x = state.rng; x ^= x << 13; x ^= x >>> 17; x ^= x << 5;
  state.rng = x >>> 0;
  return state.rng / 4294967296;
}
export function seedState(seed: string | number): number {
  if ((typeof seed !== 'string' && typeof seed !== 'number') || (typeof seed === 'number' && !Number.isFinite(seed))) throw new EngineError('INVALID_CONFIG', 'Seed must be a string or finite number');
  let hash = 2166136261;
  for (const c of String(seed)) { hash ^= c.charCodeAt(0); hash = Math.imul(hash,16777619); }
  return (hash >>> 0) || 1;
}
export function detectMatches(board: Board, matchLength = 3): Match[] {
  const rows = board.length, cols = board[0]?.length ?? 0;
  const runs: Match['runs'] = [];
  for (const orientation of ['horizontal','vertical'] as const) {
    const outer = orientation === 'horizontal' ? rows : cols, inner = orientation === 'horizontal' ? cols : rows;
    for (let a = 0; a < outer; a++) {
      let start = 0;
      while (start < inner) {
        const pos = (b: number): Position => orientation === 'horizontal' ? {row:a,col:b} : {row:b,col:a};
        const type = at(board,pos(start)).type;
        let end = start + 1;
        while (type !== null && end < inner && at(board,pos(end)).type === type) end++;
        if (type !== null && end - start >= matchLength) runs.push({orientation,cells:Array.from({length:end-start},(_,i)=>pos(start+i))});
        start = end;
      }
    }
  }
  const groups: Match[] = [];
  for (const run of runs) {
    const intersect = groups.filter(g => g.cells.some(c => run.cells.some(p => samePosition(c,p))));
    const cells = [...run.cells,...intersect.flatMap(g=>g.cells)];
    const merged: Match = {cells: [...new Map(cells.map(p=>[key(p),p])).values()].sort(order), runs:[run,...intersect.flatMap(g=>g.runs)]};
    for (const group of intersect) groups.splice(groups.indexOf(group),1);
    groups.push(merged);
  }
  for (const group of groups) group.runs.sort((a,b)=>order(a.cells[0]!,b.cells[0]!) || (a.orientation<b.orientation ? -1:a.orientation>b.orientation ? 1:0));
  return groups.sort((a,b)=>order(a.cells[0]!,b.cells[0]!));
}
export function swap(board: Board, move: Move): void {
  const piece = at(board,move.from);
  board[move.from.row]![move.from.col] = at(board,move.to);
  board[move.to.row]![move.to.col] = piece;
}
export function isLegal(board: Board, config: ResolvedConfig, move: Move): boolean {
  if (config.rules.specialSwaps && (at(board,move.from).special || at(board,move.to).special)) return true;
  const candidate = board.map(row=>row.slice()); swap(candidate,move);
  return detectMatches(candidate,config.rules.matchLength).some(g=>g.cells.some(p=>samePosition(p,move.from) || samePosition(p,move.to)));
}
export function legalMoves(board: Board, config: ResolvedConfig): Move[] {
  const moves: Move[] = [];
  for (const from of positions(config)) for (const to of [{row:from.row,col:from.col+1},{row:from.row+1,col:from.col}]) {
    if (to.row < config.rows && to.col < config.cols && isLegal(board,config,{from,to})) {
      moves.push({from,to},{from:to,to:from});
    }
  }
  return moves;
}
export function hasLegalMove(board: Board, config: ResolvedConfig): boolean {
  for (const from of positions(config)) for (const to of [{row:from.row,col:from.col+1},{row:from.row+1,col:from.col}]) {
    if (to.row < config.rows && to.col < config.cols && isLegal(board,config,{from,to})) return true;
  }
  return false;
}
export function generate(config: ResolvedConfig, rng: number): { board: Board; rng: number; nextId: number } {
  const source = {rng};
  for (let attempt=0; attempt<config.generationAttempts; attempt++) {
    const board: Board = Array.from({length:config.rows},()=>[]);
    let nextId = 1;
    for (const p of positions(config)) {
      const choices = config.pieceTypes.filter(type => {
        const n = config.rules.matchLength - 1;
        return !(p.col >= n && Array.from({length:n},(_,i)=>board[p.row]![p.col-i-1]!.type).every(t=>t===type)) &&
          !(p.row >= n && Array.from({length:n},(_,i)=>board[p.row-i-1]![p.col]!.type).every(t=>t===type));
      });
      board[p.row]![p.col] = {id:nextId++,type:choices[Math.floor(random(source)*choices.length)]!,special:null};
    }
    if (hasLegalMove(board,config)) return {board,rng:source.rng,nextId};
  }
  throw new EngineError('GENERATION_LIMIT','No playable board found within generationAttempts');
}
export function creation(group: Match, state: GameState, preferred: Position[]): { at: Position; special: Special } | null {
  const rules = state.config.rules;
  const longest = Math.max(...group.runs.map(r=>r.cells.length));
  const intersection = group.runs.some(a=>group.runs.some(b=>a.orientation!==b.orientation && a.cells.some(p=>b.cells.some(q=>samePosition(p,q)))));
  let special: Special | null = null;
  if (longest >= 5 && rules.createFive) special = 'color';
  else if (group.cells.length >= 5 && intersection && rules.createIntersection) special = 'bomb';
  else if (longest >= 4 && rules.createFour) special = group.runs.find(r=>r.cells.length===longest)!.orientation;
  if (!special) return null;
  const anchor = [...preferred,...group.cells].find(p=>group.cells.some(q=>samePosition(p,q)) && at(state.board,p).special===null);
  return anchor ? {at:copy(anchor),special} : null;
}
