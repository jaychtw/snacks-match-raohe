export type Special = 'horizontal' | 'vertical' | 'bomb' | 'color';
export interface Position { row: number; col: number }
export interface Move { from: Position; to: Position }
export interface Piece { id: number; type: string | null; special: Special | null }
export type Board = Piece[][];
export type Objective = { kind: 'score'; target: number } | { kind: 'clear'; types: string[]; target: number };
export interface Rules {
  matchLength: number;
  createFour: boolean;
  createFive: boolean;
  createIntersection: boolean;
  specialSwaps: boolean;
  bombRadius: number;
  comboLineRadius: number;
}
export interface Scoring { piecePoints: number; specialBonus: number; cascadeStep: number }
export interface Config {
  rows?: number; cols?: number; pieceTypes?: string[];
  rules?: Partial<Rules>; scoring?: Partial<Scoring>;
  objectives?: Objective[]; moveLimit?: number | null;
  maxWaves?: number; shuffleAttempts?: number; generationAttempts?: number;
}
export interface ResolvedConfig {
  rows: number; cols: number; pieceTypes: string[]; rules: Rules; scoring: Scoring;
  objectives: Objective[]; moveLimit: number | null;
  maxWaves: number; shuffleAttempts: number; generationAttempts: number;
}
export type Status = 'playing' | 'won' | 'lost';
export interface GameState {
  version: 1; config: ResolvedConfig; board: Board;
  rng: number; nextId: number; moves: number; score: number;
  cleared: Record<string, number>; status: Status;
}
export interface Cell extends Position { piece: Piece }
export interface Match { cells: Position[]; runs: { cells: Position[]; orientation: 'horizontal' | 'vertical' }[] }
export type ErrorCode = 'INVALID_CONFIG' | 'INVALID_STATE' | 'INVALID_ACTION' | 'NOT_ADJACENT' | 'NO_MATCH' | 'GAME_OVER' | 'RESOLUTION_LIMIT' | 'SHUFFLE_LIMIT' | 'UNSHUFFLABLE' | 'GENERATION_LIMIT';
export interface Failure { code: ErrorCode; message: string }
export type GameEvent =
  | { type: 'rejected'; action: unknown; error: Failure }
  | { type: 'swapped'; move: Move; fromPiece: Piece; toPiece: Piece; moves: number }
  | { type: 'matched'; wave: number; groups: Match[] }
  | { type: 'specialCreated'; wave: number; at: Position; before: Piece; piece: Piece }
  | { type: 'specialConverted'; wave: number; at: Position; before: Piece; piece: Piece }
  | { type: 'combined'; wave: number; pieces: Cell[]; targets: Position[] }
  | { type: 'activated'; wave: number; at: Position; piece: Piece; targets: Position[]; selectedType: string | null }
  | { type: 'eliminated'; wave: number; cells: Cell[] }
  | { type: 'scored'; wave: number; delta: number; total: number; multiplier: number }
  | { type: 'fell'; wave: number; pieces: { piece: Piece; from: Position; to: Position }[] }
  | { type: 'refilled'; wave: number; cells: Cell[] }
  | { type: 'objectives'; progress: { objective: Objective; current: number; complete: boolean }[] }
  | { type: 'completed'; status: 'won' | 'lost'; score: number; moves: number }
  | { type: 'reshuffled'; reason: 'deadlock' | 'requested'; before: Board; board: Board; attempts: number };
export type Result = { ok: true; state: GameState; events: GameEvent[] } | { ok: false; state: GameState; events: GameEvent[]; error: Failure };
