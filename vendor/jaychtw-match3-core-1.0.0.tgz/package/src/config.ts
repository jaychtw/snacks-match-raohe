import type { Config, ErrorCode, ResolvedConfig } from './types.js';
// Available in Node >=22 and modern browsers; no DOM typings or runtime dependency.
declare const structuredClone: <T>(value: T) => T;

export class EngineError extends Error {
  constructor(public readonly code: ErrorCode, message: string) { super(message); this.name = 'EngineError'; }
}
export const copy = <T>(value: T): T => structuredClone(value);
export function record(value: unknown): value is Record<string, unknown> {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return false;
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}
export function integer(value: unknown, min: number, max: number): value is number {
  return typeof value === 'number' && Number.isSafeInteger(value) && value >= min && value <= max;
}
function keys(value: Record<string, unknown>, allowed: string[]): void {
  if (Object.keys(value).some(k => !allowed.includes(k))) throw new EngineError('INVALID_CONFIG', 'Unknown configuration field');
}
export function resolveConfig(input: Config = {}): ResolvedConfig {
  const fail = (message: string): never => { throw new EngineError('INVALID_CONFIG', message); };
  if (!record(input)) fail('Configuration must be an object');
  keys(input as Record<string, unknown>, ['rows','cols','pieceTypes','rules','scoring','objectives','moveLimit','maxWaves','shuffleAttempts','generationAttempts']);
  const config: ResolvedConfig = {
    rows: 8, cols: 8, pieceTypes: ['a','b','c','d','e','f'],
    rules: { matchLength: 3, createFour: true, createFive: true, createIntersection: true, specialSwaps: true, bombRadius: 1, comboLineRadius: 1 },
    scoring: { piecePoints: 10, specialBonus: 20, cascadeStep: 1 },
    objectives: [], moveLimit: null, maxWaves: 100, shuffleAttempts: 1000, generationAttempts: 100,
  };
  for (const key of ['rows','cols','pieceTypes','objectives','moveLimit','maxWaves','shuffleAttempts','generationAttempts'] as const) {
    if (Object.hasOwn(input, key)) (config as unknown as Record<string, unknown>)[key] = input[key];
  }
  if (input.rules !== undefined) {
    if (!record(input.rules)) fail('rules must be an object');
    keys(input.rules, Object.keys(config.rules));
    Object.assign(config.rules, input.rules);
  }
  if (input.scoring !== undefined) {
    if (!record(input.scoring)) fail('scoring must be an object');
    keys(input.scoring, Object.keys(config.scoring));
    Object.assign(config.scoring, input.scoring);
  }
  if (!integer(config.rows,3,32) || !integer(config.cols,3,32)) fail('Dimensions must be integers from 3 to 32');
  if (!Array.isArray(config.pieceTypes) || config.pieceTypes.length < 3 || config.pieceTypes.length > 64 || Array.from(config.pieceTypes).some(t => typeof t !== 'string' || !/^[A-Za-z0-9_-]{1,64}$/.test(t) || ['__proto__','constructor','prototype'].includes(t)) || new Set(config.pieceTypes).size !== config.pieceTypes.length) fail('Use 3–64 unique safe piece identifiers');
  if (!integer(config.rules.matchLength,3,5) || (config.rows < config.rules.matchLength && config.cols < config.rules.matchLength)) fail('matchLength must be 3–5 and fit the board');
  for (const key of ['createFour','createFive','createIntersection','specialSwaps'] as const) if (typeof config.rules[key] !== 'boolean') fail(`${key} must be boolean`);
  for (const key of ['bombRadius','comboLineRadius'] as const) if (!integer(config.rules[key],1,8)) fail(`${key} must be 1–8`);
  for (const value of Object.values(config.scoring)) if (!integer(value,0,1000000)) fail('Scoring values must be integers from 0 to 1000000');
  if (config.moveLimit !== null && !integer(config.moveLimit,1,1000000)) fail('moveLimit must be null or 1–1000000');
  for (const key of ['maxWaves','shuffleAttempts','generationAttempts'] as const) if (!integer(config[key],1,10000)) fail(`${key} must be 1–10000`);
  if (!Array.isArray(config.objectives) || config.objectives.length > 100) fail('objectives must be an array with at most 100 entries');
  for (const objective of config.objectives) {
    if (!record(objective) || !integer(objective.target,1,Number.MAX_SAFE_INTEGER)) fail('Invalid objective target');
    if (objective.kind === 'score') keys(objective, ['kind','target']);
    else if (objective.kind === 'clear') {
      keys(objective, ['kind','types','target']);
      if (!Array.isArray(objective.types) || !objective.types.length || Array.from(objective.types).some(t => !config.pieceTypes.includes(t)) || new Set(objective.types).size !== objective.types.length) fail('Invalid clear objective types');
    } else fail('Unknown objective kind');
  }
  return copy(config);
}
