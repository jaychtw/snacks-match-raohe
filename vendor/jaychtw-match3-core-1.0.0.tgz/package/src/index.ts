import { at, detectMatches, generate, hasLegalMove, isLegal, legalMoves, positions, random, seedState, swap } from './board.js';
import { copy, EngineError, integer, record, resolveConfig } from './config.js';
import { resolveWave } from './effects.js';
import { objectiveProgress, statusOf, validateState } from './state.js';
import type { Config, ErrorCode, GameEvent, GameState, Move, Position, Result } from './types.js';
export type * from './types.js';
export { EngineError, resolveConfig, validateState, detectMatches };

function validPosition(value: unknown, state: GameState): value is Position {
  return record(value) && Object.keys(value).length===2 && integer(value.row,0,state.config.rows-1) && integer(value.col,0,state.config.cols-1);
}
function validateMove(value: unknown, state: GameState): ErrorCode | null {
  if (!record(value) || Object.keys(value).length!==2 || !validPosition(value.from,state) || !validPosition(value.to,state)) return 'INVALID_ACTION';
  if (Math.abs(value.from.row-value.to.row)+Math.abs(value.from.col-value.to.col)!==1) return 'NOT_ADJACENT';
  return null;
}
function reshuffle(state: GameState, events: GameEvent[], reason: 'deadlock' | 'requested'): void {
  const before = copy(state.board), pieces = before.flat(), coords = positions(state.config);
  const counts = state.config.pieceTypes.map(t=>pieces.filter(p=>p.type===t).length);
  if ((!state.config.rules.specialSwaps || !pieces.some(p=>p.special)) && Math.max(...counts)<state.config.rules.matchLength) throw new EngineError('UNSHUFFLABLE','Too few pieces of any type to form a match');
  for (let attempt=1;attempt<=state.config.shuffleAttempts;attempt++) {
    const permutation = pieces.slice();
    for (let i=permutation.length-1;i>0;i--) { const j=Math.floor(random(state)*(i+1)); [permutation[i],permutation[j]]=[permutation[j]!,permutation[i]!]; }
    state.board = Array.from({length:state.config.rows},()=>[]);
    coords.forEach((p,i)=>{state.board[p.row]![p.col]=permutation[i]!;});
    if (!detectMatches(state.board,state.config.rules.matchLength).length && hasLegalMove(state.board,state.config)) {
      events.push({type:'reshuffled',reason,before,board:copy(state.board),attempts:attempt}); return;
    }
  }
  throw new EngineError('SHUFFLE_LIMIT','No stable playable permutation found within shuffleAttempts');
}

export class Game {
  #state: GameState;
  /** Use createGame/loadGame; constructor still validates for JavaScript consumers. */
  constructor(state: GameState) { this.#state=validateState(state); }
  get state(): GameState { return copy(this.#state); }
  inspectBoard(): GameState['board'] { return copy(this.#state.board); }
  exportState(): GameState { return this.state; }
  serialize(): string { return JSON.stringify(this.#state); }
  objectives(): ReturnType<typeof objectiveProgress> { return objectiveProgress(this.#state); }
  listLegalMoves(): Move[] { return this.#state.status==='playing' ? legalMoves(this.#state.board,this.#state.config):[]; }
  isLegalMove(action: unknown): boolean { return this.#state.status==='playing' && !validateMove(action,this.#state) && isLegal(this.#state.board,this.#state.config,action as Move); }
  #failure(code: ErrorCode, message: string, ...action: [] | [unknown]): Result {
    const error = {code,message};
    // Invalid non-JSON inputs are represented by null so rejection logs remain serializable.
    let safeAction: unknown = null;
    try { safeAction=JSON.parse(JSON.stringify(action[0])); } catch { /* non-JSON input */ }
    return {ok:false,state:this.state,events:action.length===0 ? []:[{type:'rejected',action:safeAction,error}],error};
  }
  applyMove(action: unknown): Result {
    if (this.#state.status!=='playing') return this.#failure('GAME_OVER','The session has ended',action);
    const invalid = validateMove(action,this.#state);
    if (invalid) return this.#failure(invalid,'Swap requires two in-bounds orthogonally adjacent positions',action);
    const move = copy(action as Move);
    if (!isLegal(this.#state.board,this.#state.config,move)) return this.#failure('NO_MATCH','Swap creates no match or supported special interaction',action);
    const state = this.state, events: GameEvent[] = [];
    try {
      const fromPiece = copy(at(state.board,move.from)), toPiece=copy(at(state.board,move.to));
      if (!Number.isSafeInteger(state.moves+1)) throw new EngineError('RESOLUTION_LIMIT','Move counter overflow');
      state.moves++;
      swap(state.board,move);
      events.push({type:'swapped',move,fromPiece,toPiece,moves:state.moves});
      let groups = detectMatches(state.board,state.config.rules.matchLength), wave=0;
      do {
        if (wave>=state.config.maxWaves) throw new EngineError('RESOLUTION_LIMIT','Cascade exceeded maxWaves');
        resolveWave(state,groups,wave,events,wave===0 ? move:undefined);
        groups=detectMatches(state.board,state.config.rules.matchLength); wave++;
      } while (groups.length);
      state.status=statusOf(state);
      events.push({type:'objectives',progress:objectiveProgress(state)});
      if (state.status!=='playing') events.push({type:'completed',status:state.status,score:state.score,moves:state.moves});
      else if (!hasLegalMove(state.board,state.config)) reshuffle(state,events,'deadlock');
      this.#state=state;
      return {ok:true,state:this.state,events};
    } catch (error) {
      if (error instanceof EngineError) return this.#failure(error.code,error.message,action);
      throw error;
    }
  }
  reshuffle(): Result {
    if (this.#state.status!=='playing') return this.#failure('GAME_OVER','The session has ended');
    const state=this.state, events: GameEvent[]=[];
    try { reshuffle(state,events,'requested'); this.#state=state; return {ok:true,state:this.state,events}; }
    catch (error) { if (error instanceof EngineError) return this.#failure(error.code,error.message); throw error; }
  }
}
export function createGame(config: Config = {}, seed: string | number = 1): Game {
  const resolved=resolveConfig(config), initial=generate(resolved,seedState(seed));
  return new Game({version:1,config:resolved,...initial,moves:0,score:0,cleared:Object.fromEntries(resolved.pieceTypes.map(t=>[t,0])),status:'playing'});
}
export function loadGame(saved: unknown): Game {
  let input=saved;
  if (typeof saved==='string') {
    try { input=JSON.parse(saved); } catch { throw new EngineError('INVALID_STATE','Saved state is not valid JSON'); }
  }
  return new Game(validateState(input));
}
